//-----------------------------------------------------------------------------
package dk.sunepoulsen.mycash.core;

//-----------------------------------------------------------------------------
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import org.openide.modules.ModuleInfo;
import org.openide.modules.ModuleInstall;
import org.openide.util.Lookup;
import org.slf4j.LoggerFactory;
import org.slf4j.ext.XLogger;
import org.slf4j.ext.XLoggerFactory;
import org.xml.sax.InputSource;

import java.util.Collection;
import java.util.Enumeration;

//-----------------------------------------------------------------------------
/**
 * Module initializer.
 *
 * @author sunepoulsen
 */
public class Installer extends ModuleInstall {

    /**
     * Called when an already-installed module is restored (during startup).
     * <p>
     *      Loads the logback configuration from the module and initializes logback
     *      with the configuration.
     * </p>
     */
    @Override
    public void restored() {
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        try {
            JoranConfigurator configurator = new JoranConfigurator();
            configurator.setContext( context );
            configurator.doConfigure( new InputSource( getClass().getClassLoader().getResourceAsStream("logback.xml") ) );
        }
        catch( JoranException ex ) {
            logger.error( null, ex );
        }

        logger.info( "MyCash version {}", "1.0.0" );

        logger.info( "" );
        Collection<? extends ModuleInfo> modules = Lookup.getDefault().lookupAll( ModuleInfo.class );
        modules.stream().
            filter( info -> info.getCodeName().startsWith( "dk.sunepoulsen" ) ).
            filter( ModuleInfo::isEnabled ).
            forEach( info -> logger.info("Module {} ({}) ==> {} [{}]", info.getDisplayName(), info.getCodeName(), info.getSpecificationVersion(), info.getImplementationVersion()) );

        logger.info( "" );
        logger.info( "System properties:" );
        logger.info( "===================================" );
        Enumeration<?> names = System.getProperties().propertyNames();
        while( names.hasMoreElements() ) {
            String name = names.nextElement().toString();

            try {
                logger.info( "{} ==> {}", name, System.getProperty( name ) );
            }
            catch( Exception ex ) {
                logger.warn( "{} ==> Unable to read system property. Error: {} ", name, ex.getMessage() );
            }
        }
    }

    //-------------------------------------------------------------------------
    //                  Private members
    //-------------------------------------------------------------------------

    XLogger logger = XLoggerFactory.getXLogger( Installer.class );
}
