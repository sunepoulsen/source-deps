# MyCash
Financial solution for privates and small business
