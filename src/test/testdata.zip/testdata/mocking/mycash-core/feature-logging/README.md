# mycash-core
Core module for the MyCash application
