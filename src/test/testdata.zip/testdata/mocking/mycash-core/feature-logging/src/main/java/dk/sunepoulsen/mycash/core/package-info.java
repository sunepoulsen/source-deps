/**
 * Implements core non-ui functionality for the application.
 *
 * <h3>Features</h3>
 *
 * <dl>
 *     <dt>Logging</dt>
 *     <dd>Initialization of logging with logback.</dd>
 * </dl>
 */
package dk.sunepoulsen.mycash.core;
