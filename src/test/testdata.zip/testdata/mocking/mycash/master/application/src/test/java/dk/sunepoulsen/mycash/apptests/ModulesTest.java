//-----------------------------------------------------------------------------
package dk.sunepoulsen.mycash.apptests;

//-----------------------------------------------------------------------------
import junit.framework.Test;
import org.netbeans.junit.NbModuleSuite;
import org.netbeans.junit.NbTestCase;
import org.openide.modules.ModuleInfo;
import org.openide.util.Lookup;
import org.slf4j.ext.XLogger;
import org.slf4j.ext.XLoggerFactory;

import java.util.Collection;
import java.util.logging.Level;

//-----------------------------------------------------------------------------
/**
 * Tests that different modules can be loaded correctly into the cluster.
 * <p>
 *     This is simply done by testing that we can use some of the code in the
 *     tested module from this class.
 * </p>
 */
public class ModulesTest extends NbTestCase {
    public static Test suite() {
        return NbModuleSuite.createConfiguration(ModulesTest.class).
                gui(false).
                failOnMessage(Level.SEVERE). // works at least in RELEASE71
                failOnException(Level.SEVERE).
                enableClasspathModules(true).
                clusters(".*").
                suite();
    }

    public ModulesTest( String n ) {
        super( n );
    }

    /**
     * Testing that our modules could be loaded.
     */
    public void testModulesIsLoaded() {
        logger.entry();

        try {
            // Testing branding
            assertTrue( moduleExists( "dk.sunepoulsen.mycash.branding" ) );

            // Testing MyCash modules
            assertTrue( moduleExists( "dk.sunepoulsen.mycash.core" ) );

            // Testing NBM Commons modules
            assertTrue( moduleExists( "dk.sunepoulsen.nbm.logback" ) );
        }
        finally {
            logger.exit();
        }
    }

    private boolean moduleExists( String moduleName ) {
        logger.entry();

        Boolean result = null;
        try {
            Collection<? extends ModuleInfo> modules = Lookup.getDefault().lookupAll( ModuleInfo.class );
            for( ModuleInfo info : modules ) {
                if( info.getCodeName().equals( moduleName ) ) {
                    return result = true;
                }
            }

            return result = false;
        }
        finally {
            logger.exit( result );
        }
    }

    //-------------------------------------------------------------------------
    //                  Private members
    //-------------------------------------------------------------------------

    XLogger logger = XLoggerFactory.getXLogger( ModulesTest.class );
}
